from app.core import RiskEngine,CircuitBreaker,Leg,Route
def test_risk(): assert not RiskEngine(100).approve(101,1)
def test_breaker():
 c=CircuitBreaker(3); c.record_result(-1); c.record_result(-1); assert not c.tripped; c.record_result(-1); assert c.tripped
def test_route():
 r=Route([Leg("A","BTC/USDT","BUY",1,100)],5,1,.5); assert r.net_profit==3.5
