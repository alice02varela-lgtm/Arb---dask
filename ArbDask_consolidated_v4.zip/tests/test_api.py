from fastapi.testclient import TestClient
from app.main import app
c=TestClient(app)
def test_health(): assert c.get("/api/health").status_code==200
def test_opportunity():
 r=c.post("/api/opportunity",json={"buy_exchange":"BINANCE_TESTNET","sell_exchange":"OKX_DEMO","buy_price":100,"sell_price":102,"quantity":1}); assert r.status_code==200 and r.json()["profit_pct"]>0
def test_stop():
 c.post("/api/emergency-reset"); assert c.post("/api/emergency-stop").status_code==200; c.post("/api/emergency-reset")
