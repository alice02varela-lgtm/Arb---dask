from fastapi import FastAPI,HTTPException
from pydantic import BaseModel,Field
from .core import RiskEngine,CircuitBreaker,Leg,Route
from .connectors import BinanceTestnet,OKXDemo
from .orchestrator import AutoBot
from .market import opportunity
app=FastAPI(title="ArbDask",version="4.0.0")
risk=RiskEngine(); breaker=CircuitBreaker(3); stopped=False
connectors={"BINANCE_TESTNET":BinanceTestnet(),"OKX_DEMO":OKXDemo()}; bot=AutoBot(connectors,risk,breaker)
class OpportunityRequest(BaseModel):
    symbol:str="BTC/USDT"; buy_exchange:str; buy_price:float=Field(gt=0); sell_exchange:str; sell_price:float=Field(gt=0); quantity:float=Field(gt=0)
class RunRequest(OpportunityRequest): pass
@app.get("/api/health")
def health(): return {"ok":True,"service":"ArbDask","version":"4.0.0","mode":"paper","live_trading_enabled":False,"emergency_stop":stopped or breaker.tripped}
@app.get("/api/connectors")
def connector_health(): return {n:c.health().data for n,c in connectors.items()}
@app.post("/api/opportunity")
def calculate(req:OpportunityRequest):
    x=opportunity(req.symbol,req.buy_exchange,req.buy_price,req.sell_exchange,req.sell_price,req.quantity)
    if x is None: raise HTTPException(400,"invalid market data")
    return x.__dict__
@app.post("/api/emergency-stop")
def emergency_stop():
    global stopped; stopped=True; breaker.tripped=True; return {"ok":True,"stopped":True}
@app.post("/api/emergency-reset")
def emergency_reset():
    global stopped; stopped=False; breaker.reset(); return {"ok":True,"stopped":False}
@app.post("/api/autobot/run")
def autobot_run(req:RunRequest):
    if stopped: raise HTTPException(423,"emergency stop active")
    q=req.buy_price*req.quantity; route=Route([Leg(req.buy_exchange,req.symbol,"BUY",req.quantity,req.buy_price),Leg(req.sell_exchange,req.symbol,"SELL",req.quantity,req.sell_price)])
    r=bot.execute(route,q)
    if not r["ok"]: raise HTTPException(409,r["reason"])
    return r
@app.get("/")
def root(): return {"name":"ArbDask","status":"online","docs":"/docs"}
