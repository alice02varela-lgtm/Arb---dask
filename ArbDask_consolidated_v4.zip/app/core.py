from dataclasses import dataclass
from enum import Enum
from typing import List

class OrderState(str, Enum):
    CREATED="created"; SUBMITTED="submitted"; FILLED="filled"; FAILED="failed"; CANCELLED="cancelled"

@dataclass
class Leg:
    exchange:str; symbol:str; side:str; quantity:float; price:float

@dataclass
class Route:
    legs:List[Leg]; expected_profit:float=0.0; fees:float=0.0; slippage:float=0.0
    @property
    def net_profit(self): return self.expected_profit-self.fees-self.slippage

class CircuitBreaker:
    def __init__(self,max_consecutive_losses=3): self.max_consecutive_losses=max_consecutive_losses; self.consecutive_losses=0; self.tripped=False
    def record_result(self,profit):
        self.consecutive_losses=self.consecutive_losses+1 if profit<0 else 0
        if self.consecutive_losses>=self.max_consecutive_losses: self.tripped=True
    def reset(self): self.consecutive_losses=0; self.tripped=False

class RiskEngine:
    def __init__(self,max_trade_quote=100.0,min_profit_pct=0.30): self.max_trade_quote=max_trade_quote; self.min_profit_pct=min_profit_pct
    def approve(self,quote_amount,profit_pct,stopped=False): return (not stopped and 0<quote_amount<=self.max_trade_quote and profit_pct>=self.min_profit_pct)
