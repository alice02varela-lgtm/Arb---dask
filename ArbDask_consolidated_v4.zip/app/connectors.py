from dataclasses import dataclass
@dataclass
class Result:
    ok:bool; message:str; data:dict|None=None
class BaseConnector:
    name="BASE"
    def health(self): return Result(True,"connector ready",{"mode":"demo"})
    def balances(self): return Result(True,"demo balances",{"USDT":1000.0})
    def place_order(self,symbol,side,quantity,price): return Result(True,"paper order accepted",{"symbol":symbol,"side":side,"quantity":quantity,"price":price})
class BinanceTestnet(BaseConnector): name="BINANCE_TESTNET"
class OKXDemo(BaseConnector): name="OKX_DEMO"
