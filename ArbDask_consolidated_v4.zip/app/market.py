from dataclasses import dataclass
@dataclass
class Opportunity:
    symbol:str; buy_exchange:str; sell_exchange:str; buy_price:float; sell_price:float; quantity:float; gross_profit:float; profit_pct:float

def opportunity(symbol,buy_exchange,buy_price,sell_exchange,sell_price,quantity,fee_pct=0.10):
    if min(buy_price,sell_price,quantity)<=0:return None
    gross=(sell_price-buy_price)*quantity; notional=buy_price*quantity; fees=notional*(fee_pct/100)*2; net=gross-fees
    return Opportunity(symbol,buy_exchange,sell_exchange,buy_price,sell_price,quantity,net,(net/notional)*100)
