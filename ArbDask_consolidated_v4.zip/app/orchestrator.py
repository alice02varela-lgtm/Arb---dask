import uuid
from .core import Route,OrderState
class AutoBot:
    def __init__(self,connectors,risk,breaker): self.connectors=connectors; self.risk=risk; self.breaker=breaker
    def execute(self,route,quote_amount):
        if self.breaker.tripped:return {"ok":False,"reason":"circuit_breaker"}
        if not route.legs:return {"ok":False,"reason":"empty_route"}
        pct=route.net_profit/quote_amount*100 if quote_amount else 0
        if not self.risk.approve(quote_amount,pct):return {"ok":False,"reason":"risk_rejected"}
        results=[]
        for leg in route.legs:
            c=self.connectors.get(leg.exchange)
            if not c:return {"ok":False,"reason":f"unknown_connector:{leg.exchange}"}
            results.append(c.place_order(leg.symbol,leg.side,leg.quantity,leg.price))
        return {"ok":all(r.ok for r in results),"order_id":str(uuid.uuid4()),"state":OrderState.FILLED.value,"results":[r.data for r in results]}
