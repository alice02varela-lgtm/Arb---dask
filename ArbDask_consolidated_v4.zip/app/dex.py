class DEXGuard:
    def __init__(self,max_slippage_pct=0.50): self.max_slippage_pct=max_slippage_pct
    def approve(self,slippage_pct): return 0<=slippage_pct<=self.max_slippage_pct
