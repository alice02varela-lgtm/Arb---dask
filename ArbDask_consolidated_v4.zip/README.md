# ArbDask 4.0 — Consolidated MVP

Crypto-arbitrage control plane for Paper Trading, Binance Spot Testnet and OKX Demo.

Safety defaults: paper mode, live trading disabled, no withdrawals, trade-size limit and emergency stop/circuit breaker after 3 consecutive losses.

This is a functional MVP for testing. It is NOT a claim that live-money trading is safe or profitable.

## Run
`pip install -r requirements.txt`
`uvicorn app.main:app --host 0.0.0.0 --port 8000`

## Test
`pytest -q`

Before any live deployment: authenticated exchange E2E tests, exchange filters, reconciliation, failure injection, persistent audit logs, secrets management, rate-limit handling, monitoring and security review are required.
